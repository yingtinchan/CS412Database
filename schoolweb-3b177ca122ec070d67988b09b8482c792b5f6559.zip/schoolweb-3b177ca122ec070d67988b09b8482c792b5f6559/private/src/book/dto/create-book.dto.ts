export class CreateBookDto {
    name: string;
    category: string;
    author: string;
    description: string;
}
