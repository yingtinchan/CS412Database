export class CreateTeacherDto {
    teacher_id: string;
    name: string;
    password: string;
    email: string;
}
