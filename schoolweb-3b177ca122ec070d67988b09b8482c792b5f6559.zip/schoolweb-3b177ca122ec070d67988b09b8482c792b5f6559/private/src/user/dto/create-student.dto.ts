export class CreateStudentDto {
    student_id: string;
    name: string;
    password: string;
    email: string;
    major_id: string;
}
