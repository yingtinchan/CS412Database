export class CreateAdminDto {
    admin_id: string;
    name: string;
    password: string;
    email: string;
}
