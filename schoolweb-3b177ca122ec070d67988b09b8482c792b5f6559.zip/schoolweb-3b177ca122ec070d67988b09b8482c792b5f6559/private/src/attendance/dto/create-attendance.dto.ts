export class CreateAttendanceDto {
    lecture_id: string;
    student_id: string;
    attendance: boolean
}
