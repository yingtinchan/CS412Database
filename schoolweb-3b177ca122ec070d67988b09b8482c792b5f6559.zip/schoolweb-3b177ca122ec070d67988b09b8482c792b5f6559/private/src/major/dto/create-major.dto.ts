export class CreateMajorDto {
    major_id: string;
    name: string;    
}
