export const jwtConstants = {
    secret: 'mysecret',
  };